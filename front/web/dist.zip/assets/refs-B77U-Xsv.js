import{aW as c}from"./index-CcWsJb4E.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};
