import{a$ as a}from"./index-CcWsJb4E.js";function e(){if(!arguments.length)return[];var r=arguments[0];return a(r)?r:[r]}export{e as c};
